# Current-run synthesis

E2: mean Δ +0.076337, median +0.023111, 95% interval [+0.027704, +0.137140], CV wins 17/50.

E3: mean Δ -0.400703, median -0.364298, 95% interval [-0.500802, -0.301900], CV wins 44/50.

E4: mean Δ +0.157758, median -0.026330; CV wins 5/10. This is descriptive evidence from dependent historical blocks.

Interpret this table alongside the complete distributions, failures, calibration and baseline comparisons.
