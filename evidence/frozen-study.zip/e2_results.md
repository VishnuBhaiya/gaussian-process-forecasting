### E2: current-run results

Successful pairs: **50/50**. Mean Δ: **+0.076337**; median: **+0.023111**. 95% paired-bootstrap interval: **[+0.027704, +0.137140]**. CV wins: **17**, exact ties: **0**. Interpretation: **LML advantage** under this frozen generator. This is a conditional average result, not universal superiority.