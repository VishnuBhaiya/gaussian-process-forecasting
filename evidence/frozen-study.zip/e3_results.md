### E3: current-run results

Successful pairs: **50/50**. Mean Δ: **-0.400703**; median: **-0.364298**. 95% paired-bootstrap interval: **[-0.500802, -0.301900]**. CV wins: **44**, exact ties: **0**. Interpretation: **CV advantage** under this frozen generator. This is a conditional average result, not universal superiority.